from flask import Flask, render_template, redirect, url_for, request, session, flash
from werkzeug.security import check_password_hash
from functools import wraps
from flask_mysqldb import MySQL
import config

app = Flask(__name__)
app.secret_key = 'portfolio_secret_2026'

app.config['MYSQL_HOST']        = 'db'
app.config['MYSQL_USER']        = 'portfolio_user'
app.config['MYSQL_PASSWORD']    = 'portfolio_pass'
app.config['MYSQL_DB']          = 'portfolio_db'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

app.config['MYSQL_CHARSET'] = 'utf8mb4'  # ← ici
mysql = MySQL(app)


# ============================================================
# DÉCORATEUR ADMIN
# ============================================================
def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'admin' not in session:
            flash('Connectez-vous pour accéder à cette page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


# ============================================================
# PAGE PRINCIPALE
# ============================================================
@app.route('/')
def index():
    is_admin = 'admin' in session

    try:
        cur = mysql.connection.cursor()
        cur.execute("""
            SELECT b.id as bloc_id, b.code as bloc_code, b.nom as bloc_nom,
                   b.icone, b.couleur,
                   ac.id as ac_id, ac.code as ac_code, ac.label, ac.niveau,
                   ac.semestre_id as ac_sem_id,
                   s.code as sem_code, s.nom as sem_nom,
                   ac.fait, ac.pourquoi, ac.comment_fait,
                   ac.difficultes, ac.appris, ac.autrement,
                   ac.projet_titre, ac.projet_lien, ac.projet_desc
            FROM bloc b
            LEFT JOIN apprentissage_critique ac ON ac.bloc_id = b.id
            LEFT JOIN semestre s ON s.id = ac.semestre_id
            ORDER BY b.id, ac.semestre_id, ac.code
        """)
        rows = cur.fetchall()
        cur.close()

        blocs = {}
        for r in rows:
            bid = r['bloc_code']
            if bid not in blocs:
                blocs[bid] = {
                    'id':        r['bloc_code'],
                    'label':     r['bloc_nom'],
                    'icone':     r['icone'],
                    'couleur':   r['couleur'],
                    'semestres': {}
                }
            if r['ac_id']:
                sem_code = r['sem_code'] or 'S1'
                sem_nom  = r['sem_nom']  or 'Semestre 1'
                if sem_code not in blocs[bid]['semestres']:
                    blocs[bid]['semestres'][sem_code] = {
                        'code': sem_code,
                        'nom':  sem_nom,
                        'acs':  []
                    }
                blocs[bid]['semestres'][sem_code]['acs'].append({
                    'id':           r['ac_id'],
                    'code':         r['ac_code'],
                    'label':        r['label'],
                    'niveau':       r['niveau'],
                    'semestre':     sem_code,
                    'fait':         r['fait']         or '',
                    'pourquoi':     r['pourquoi']     or '',
                    'comment_fait': r['comment_fait'] or '',
                    'difficultes':  r['difficultes']  or '',
                    'appris':       r['appris']        or '',
                    'autrement':    r['autrement']    or '',
                    'projet_titre': r['projet_titre'] or '',
                    'projet_lien':  r['projet_lien']  or '',
                    'projet_desc':  r['projet_desc']  or '',
                })

        competences = []
        for b in blocs.values():
            b['semestres'] = sorted(
                b['semestres'].values(), key=lambda x: x['code']
            )
            b['acs'] = []
            for sem in b['semestres']:
                b['acs'].extend(sem['acs'])
            competences.append(b)

    except Exception as e:
        print('MySQL error:', e)
        competences = config.COMPETENCES

    try:
        cv_data = get_cv_data()
    except Exception:
        cv_data = {'formation': [], 'experience': [], 'certification': []}

    return render_template('index.html',
                           profile=config.PROFILE,
                           competences=competences,
                           cv_data=cv_data,
                           is_admin=is_admin)
# ============================================================
# AJOUTER UNE COMPÉTENCE  ( GET /admin/ac/ajouter )
# ============================================================
@app.route('/admin/ac/ajouter', methods=['GET', 'POST'])
@admin_required
def ajouter_ac():
    cur = mysql.connection.cursor()
    cur.execute("SELECT id, code, nom FROM bloc ORDER BY nom")
    blocs = cur.fetchall()
    cur.execute("SELECT id, code, nom FROM semestre ORDER BY id")
    semestres = cur.fetchall()

    if request.method == 'POST':
        code         = request.form.get('code',         '').strip()
        label        = request.form.get('label',        '').strip()
        niveau       = request.form.get('niveau',       'non_acquis')
        bloc_id      = request.form.get('bloc_id')
        semestre_id  = request.form.get('semestre_id')
        fait         = request.form.get('fait',         '').strip()
        pourquoi     = request.form.get('pourquoi',     '').strip()
        comment_fait = request.form.get('comment_fait', '').strip()
        difficultes  = request.form.get('difficultes',  '').strip()
        appris       = request.form.get('appris',       '').strip()
        autrement    = request.form.get('autrement',    '').strip()
        projet_titre = request.form.get('projet_titre', '').strip()
        projet_lien  = request.form.get('projet_lien',  '').strip()
        projet_desc  = request.form.get('projet_desc',  '').strip()

        niveaux_valides = ['non_acquis','en_cours','presque_acquis','acquis','expert']

        if not code or not label or not bloc_id or not semestre_id:
            flash('Code, Description, Bloc et Semestre sont obligatoires.', 'danger')
        elif niveau not in niveaux_valides:
            flash('Niveau invalide.', 'danger')
        else:
            cur.execute("""
                INSERT INTO apprentissage_critique
                (code, label, niveau, bloc_id, semestre_id,
                 fait, pourquoi, comment_fait, difficultes, appris, autrement,
                 projet_titre, projet_lien, projet_desc)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """, (code, label, niveau, bloc_id, semestre_id,
                  fait, pourquoi, comment_fait, difficultes, appris, autrement,
                  projet_titre, projet_lien, projet_desc))
            mysql.connection.commit()
            cur.close()
            flash('Compétence ajoutée !', 'success')
            return redirect(url_for('index') + '#support-portfolio')

    cur.close()
    return render_template('admin/ajouter_ac.html',
                           profile=config.PROFILE,
                           blocs=blocs,
                           semestres=semestres)
# ============================================================
# MODIFIER UNE COMPÉTENCE  ( GET+POST /admin/ac/<id>/modifier )
# ============================================================
@app.route('/admin/ac/<int:ac_id>/modifier', methods=['GET', 'POST'])
@admin_required
def modifier_ac(ac_id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM apprentissage_critique WHERE id = %s", (ac_id,))
    ac = cur.fetchone()

    if not ac:
        flash('Compétence introuvable.', 'danger')
        return redirect(url_for('index'))

    cur.execute("SELECT id, code, nom FROM bloc ORDER BY nom")
    blocs = cur.fetchall()

    if request.method == 'POST':
        code         = request.form.get('code',         '').strip()
        label        = request.form.get('label',        '').strip()
        niveau       = request.form.get('niveau',       'non_acquis')
        bloc_id      = request.form.get('bloc_id')
        fait         = request.form.get('fait',         '').strip()
        pourquoi     = request.form.get('pourquoi',     '').strip()
        comment_fait = request.form.get('comment_fait', '').strip()
        difficultes  = request.form.get('difficultes',  '').strip()
        appris       = request.form.get('appris',       '').strip()
        autrement    = request.form.get('autrement',    '').strip()
        projet_titre = request.form.get('projet_titre', '').strip()
        projet_lien  = request.form.get('projet_lien',  '').strip()
        projet_desc  = request.form.get('projet_desc',  '').strip()

        niveaux_valides = ['non_acquis', 'en_cours', 'presque_acquis', 'acquis', 'expert']

        if not code or not label or not bloc_id:
            flash('Les champs Code, Description et Bloc sont obligatoires.', 'danger')
        elif niveau not in niveaux_valides:
            flash('Niveau invalide.', 'danger')
        else:
            cur.execute("""
                UPDATE apprentissage_critique
                SET code=%s, label=%s, niveau=%s, bloc_id=%s,
                    fait=%s, pourquoi=%s, comment_fait=%s,
                    difficultes=%s, appris=%s, autrement=%s,
                    projet_titre=%s, projet_lien=%s, projet_desc=%s
                WHERE id=%s
            """, (code, label, niveau, bloc_id,
                  fait, pourquoi, comment_fait,
                  difficultes, appris, autrement,
                  projet_titre, projet_lien, projet_desc,
                  ac_id))
            mysql.connection.commit()
            cur.close()
            flash('Compétence modifiée avec succès !', 'success')
            return redirect(url_for('index') + '#support-portfolio')

    cur.close()
    return render_template('admin/modifier_ac.html',
                           profile=config.PROFILE,
                           ac=ac,
                           blocs=blocs)


# ============================================================
# SUPPRIMER UNE COMPÉTENCE  ( POST /admin/ac/<id>/supprimer )
# ============================================================
@app.route('/admin/ac/<int:ac_id>/supprimer', methods=['POST'])
@admin_required
def supprimer_ac(ac_id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM apprentissage_critique WHERE id = %s", (ac_id,))
    mysql.connection.commit()
    cur.close()
    flash('Compétence supprimée.', 'info')
    return redirect(url_for('index') + '#support-portfolio')


# ============================================================
# LOGIN / LOGOUT
# ============================================================
@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'admin' in session:
        return redirect(url_for('index'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        if (username == config.ADMIN['username'] and
                check_password_hash(config.ADMIN['password_hash'], password)):
            session['admin'] = username
            flash('Connecté !', 'success')
            return redirect(url_for('index'))
        flash('Identifiants incorrects.', 'danger')
    return render_template('login.html', profile=config.PROFILE)


@app.route('/logout')
def logout():
    session.pop('admin', None)
    session.pop('niveaux', None)
    flash('Déconnecté.', 'info')
    return redirect(url_for('index'))




# ============================================================
# CV — récupère les données depuis MySQL
# ============================================================
def get_cv_data():
    """Récupère formations, expériences et certifications depuis MySQL."""
    cur = mysql.connection.cursor()

    # Récupère tous les items avec leurs tags et points
    cur.execute("SELECT * FROM cv_item ORDER BY type, ordre")
    items = cur.fetchall()

    result = {'formation': [], 'experience': [], 'certification': []}

    for item in items:
        # Tags
        cur.execute("SELECT tag FROM cv_tag WHERE item_id = %s", (item['id'],))
        tags = [r['tag'] for r in cur.fetchall()]

        # Points (pour expériences)
        cur.execute("SELECT contenu FROM cv_point WHERE item_id = %s", (item['id'],))
        points = [r['contenu'] for r in cur.fetchall()]

        result[item['type']].append({
            'id':           item['id'],
            'periode':      item['periode'],
            'titre':        item['titre'],
            'organisation': item['organisation'],
            'description':  item['description'],
            'tags':         tags,
            'points':       points,
            'ordre':        item['ordre']
        })

    cur.close()
    return result

# ============================================================
# AJOUTER UN ITEM CV
# ============================================================
@app.route('/admin/cv/ajouter', methods=['GET', 'POST'])
@admin_required
def ajouter_cv():
    if request.method == 'POST':
        type_item    = request.form.get('type',         '').strip()
        periode      = request.form.get('periode',      '').strip()
        titre        = request.form.get('titre',        '').strip()
        organisation = request.form.get('organisation', '').strip()
        description  = request.form.get('description',  '').strip()
        tags_raw     = request.form.get('tags',         '').strip()
        points_raw   = request.form.get('points',       '').strip()

        types_valides = ['formation', 'experience', 'certification']

        if not type_item or not periode or not titre or not organisation:
            flash('Les champs Type, Période, Titre et Organisation sont obligatoires.', 'danger')
        elif type_item not in types_valides:
            flash('Type invalide.', 'danger')
        else:
            cur = mysql.connection.cursor()

            # Calcule l'ordre (dernier + 1)
            cur.execute("SELECT MAX(ordre) as max_ordre FROM cv_item WHERE type=%s", (type_item,))
            row = cur.fetchone()
            ordre = (row['max_ordre'] or 0) + 1

            # Insère l'item
            cur.execute("""
                INSERT INTO cv_item (type, periode, titre, organisation, description, ordre)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (type_item, periode, titre, organisation, description, ordre))
            item_id = cur.lastrowid

            # Insère les tags (séparés par des virgules)
            if tags_raw:
                for tag in [t.strip() for t in tags_raw.split(',') if t.strip()]:
                    cur.execute("INSERT INTO cv_tag (item_id, tag) VALUES (%s, %s)",
                                (item_id, tag))

            # Insère les points (un par ligne)
            if points_raw:
                for point in [p.strip() for p in points_raw.split('\n') if p.strip()]:
                    cur.execute("INSERT INTO cv_point (item_id, contenu) VALUES (%s, %s)",
                                (item_id, point))

            mysql.connection.commit()
            cur.close()
            flash('Élément CV ajouté avec succès !', 'success')
            return redirect(url_for('index') + '#resume')

    return render_template('admin/ajouter_cv.html', profile=config.PROFILE)

# ============================================================
# MODIFIER UN ITEM CV
# ============================================================
@app.route('/admin/cv/<int:item_id>/modifier', methods=['GET', 'POST'])
@admin_required
def modifier_cv(item_id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM cv_item WHERE id = %s", (item_id,))
    item = cur.fetchone()

    if not item:
        flash('Élément introuvable.', 'danger')
        return redirect(url_for('index') + '#resume')

    # Récupère tags et points existants
    cur.execute("SELECT tag FROM cv_tag WHERE item_id = %s", (item_id,))
    tags = ', '.join([r['tag'] for r in cur.fetchall()])

    cur.execute("SELECT contenu FROM cv_point WHERE item_id = %s", (item_id,))
    points = '\n'.join([r['contenu'] for r in cur.fetchall()])

    if request.method == 'POST':
        periode      = request.form.get('periode',      '').strip()
        titre        = request.form.get('titre',        '').strip()
        organisation = request.form.get('organisation', '').strip()
        description  = request.form.get('description',  '').strip()
        tags_raw     = request.form.get('tags',         '').strip()
        points_raw   = request.form.get('points',       '').strip()

        if not periode or not titre or not organisation:
            flash('Les champs Période, Titre et Organisation sont obligatoires.', 'danger')
        else:
            # Met à jour l'item
            cur.execute("""
                UPDATE cv_item SET periode=%s, titre=%s, organisation=%s, description=%s
                WHERE id=%s
            """, (periode, titre, organisation, description, item_id))

            # Supprime et réinsère les tags
            cur.execute("DELETE FROM cv_tag WHERE item_id = %s", (item_id,))
            if tags_raw:
                for tag in [t.strip() for t in tags_raw.split(',') if t.strip()]:
                    cur.execute("INSERT INTO cv_tag (item_id, tag) VALUES (%s, %s)",
                                (item_id, tag))

            # Supprime et réinsère les points
            cur.execute("DELETE FROM cv_point WHERE item_id = %s", (item_id,))
            if points_raw:
                for point in [p.strip() for p in points_raw.split('\n') if p.strip()]:
                    cur.execute("INSERT INTO cv_point (item_id, contenu) VALUES (%s, %s)",
                                (item_id, point))

            mysql.connection.commit()
            cur.close()
            flash('Élément CV modifié !', 'success')
            return redirect(url_for('index') + '#resume')

    cur.close()
    return render_template('admin/modifier_cv.html',
                           profile=config.PROFILE,
                           item=item,
                           tags=tags,
                           points=points)

# ============================================================
# SUPPRIMER UN ITEM CV
# ============================================================
@app.route('/admin/cv/<int:item_id>/supprimer', methods=['POST'])
@admin_required
def supprimer_cv(item_id):
    cur = mysql.connection.cursor()
    # ON DELETE CASCADE supprime automatiquement tags et points
    cur.execute("DELETE FROM cv_item WHERE id = %s", (item_id,))
    mysql.connection.commit()
    cur.close()
    flash('Élément supprimé.', 'info')
    return redirect(url_for('index') + '#resume')

# ============================================================
# LANCEMENT
# ============================================================
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)