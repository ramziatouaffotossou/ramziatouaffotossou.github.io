# ============================================================
# IMPORTS
# ============================================================
from werkzeug.security import generate_password_hash
# Fonction qui transforme un mot de passe en clair en une "empreinte" (hash)
# Ex : "motdepasse123" → "pbkdf2:sha256:260000$x7k...  (chaîne illisible)
# Ainsi le vrai mot de passe n'est JAMAIS stocké directement dans le code


# ============================================================
# PROFIL  —  Données personnelles affichées sur le portfolio
# ============================================================
# Ce dictionnaire est passé à tous les templates HTML via app.py (render_template)
# Tu peux modifier n'importe quelle valeur ici, ça se répercute partout sur le site
PROFILE = {
    "nom":           "Ramziatou AFFO TOSSOU",       # Nom complet affiché
    "prenom":        "Ramziatou",                   # Prénom seul (pour les salutations)
    "nom_famille":   "AFFO TOSSOU",                 # Nom de famille seul
    "titre":         "Experte en Cybersécurité",    # Titre affiché sous ton nom
    "email":         "at.ramziatou@gmail.com",      # Email de contact
    "github":        "https://github.com/ramziatouaffotossou",
    "linkedin":      "https://www.linkedin.com/in/ramziatou-affo-tossou-7ba4a7397/",
    "localite":      "Béthune, France",             # Ville affichée sur le portfolio
    "etablissement": "IUT de Béthune – Université d'Artois",
    "formation":     "BUT Réseaux & Télécommunications – Cybersécurité",
    "bio":           "Originaire du Bénin, je développe mes compétences en sécurité des systèmes d'information à l'IUT de Béthune. Mon objectif : protéger et superviser les infrastructures numériques dans un environnement en constante évolution.",
    "cv_pdf":        "monparcours.pdf",             # Nom du fichier PDF dans /static (lien de téléchargement)
}


# ============================================================
# ADMIN  —  Identifiants de connexion à l'interface d'administration
# ============================================================
# Ces valeurs sont utilisées dans app.py route /login pour vérifier la connexion
#
# ✅ Identifiants actuels :
#       Nom d'utilisateur : admin
#       Mot de passe      : motdepasse123
#
# ⚠️  Pour changer le mot de passe, remplace simplement "motdepasse123"
#     par ton nouveau mot de passe dans generate_password_hash(...)
ADMIN = {
    "username":      "admin",
    "password_hash": generate_password_hash("motdepasse123"),
    # generate_password_hash génère un hash différent à chaque démarrage,
    # mais check_password_hash dans app.py sait quand même le vérifier correctement
}


# ============================================================
# COMPÉTENCES  —  Liste des ACs (Apprentissages Critiques) du BUT R&T
# ============================================================
# Structure : liste de 5 compétences, chacune contenant une liste d'ACs
# Chaque AC a un niveau initial défini ici, modifiable via l'interface admin
#
# Niveaux possibles (du plus faible au plus fort) :
#   "non_acquis" → "en_cours" → "presque_acquis" → "acquis" → "expert"
#
# Ces données sont passées au template HTML via app.py (render_template)
# et les niveaux modifiés par l'admin sont stockés dans la session Flask
COMPETENCES = [

    # ----------------------------------------------------------
    # COMPÉTENCE 1 : ADMINISTRER
    # Gestion et configuration des équipements réseau
    # ----------------------------------------------------------
    {
        "id":      "administrer",
        "label":   "Administrer",
        "icone":   "bi-gear-fill",       # Icône Bootstrap Icons affichée dans le template
        "couleur": "#c41e3a",            # Couleur rouge associée à cette compétence
        "acs": [
            {"id": 1,  "code": "AC11.01", "niveau": "acquis",         "label": "Maîtriser les lois fondamentales de l'électricité afin d'intervenir sur des équipements de réseaux"},
            {"id": 2,  "code": "AC11.02", "niveau": "acquis",         "label": "Comprendre l'architecture et les fondements des systèmes numériques"},
            {"id": 3,  "code": "AC11.03", "niveau": "en_cours",       "label": "Configurer les fonctions de base du réseau local"},
            {"id": 4,  "code": "AC11.04", "niveau": "en_cours",       "label": "Maîtriser les rôles et principes fondamentaux des systèmes d'exploitation"},
            {"id": 5,  "code": "AC11.05", "niveau": "presque_acquis", "label": "Identifier les dysfonctionnements du réseau local et savoir les signaler"},
            {"id": 6,  "code": "AC11.06", "niveau": "acquis",         "label": "Installer un poste client, expliquer la procédure mise en place"},
        ]
    },

    # ----------------------------------------------------------
    # COMPÉTENCE 2 : CONNECTER
    # Technologies filaires, sans fil et longue distance
    # ----------------------------------------------------------
    {
        "id":      "connecter",
        "label":   "Connecter",
        "icone":   "bi-hdd-network-fill",
        "couleur": "#e07a3f",            # Couleur orange
        "acs": [
            {"id": 7,  "code": "AC12.01", "niveau": "acquis",         "label": "Maîtriser les technologies filaires des réseaux locaux"},
            {"id": 8,  "code": "AC12.02", "niveau": "en_cours",       "label": "Maîtriser les technologies des réseaux locaux sans fil"},
            {"id": 9,  "code": "AC12.03", "niveau": "presque_acquis", "label": "Mettre en place un réseau local"},
            {"id": 10, "code": "AC12.04", "niveau": "en_cours",       "label": "Maîtriser les technologies de transmission sur longue distance"},
            {"id": 11, "code": "AC12.05", "niveau": "acquis",         "label": "Communiquer avec un client ou un utilisateur"},
        ]
    },

    # ----------------------------------------------------------
    # COMPÉTENCE 3 : PROGRAMMER
    # Développement, algorithmique et web
    # ----------------------------------------------------------
    {
        "id":      "programmer",
        "label":   "Programmer",
        "icone":   "bi-code-slash",
        "couleur": "#f4c430",            # Couleur jaune/or
        "acs": [
            {"id": 12, "code": "AC13.01", "niveau": "acquis",         "label": "Utiliser un système informatique et ses outils"},
            {"id": 13, "code": "AC13.02", "niveau": "acquis",         "label": "Lire, comprendre, exécuter, corriger et modifier un programme"},
            {"id": 14, "code": "AC13.03", "niveau": "presque_acquis", "label": "Traduire un algorithme dans un langage et pour un environnement donné"},
            {"id": 15, "code": "AC13.04", "niveau": "acquis",         "label": "Connaître l'architecture et les technologies d'un site Web"},
            {"id": 16, "code": "AC13.05", "niveau": "acquis",         "label": "Utiliser les frameworks et bibliothèques"},
        ]
    },

    # ----------------------------------------------------------
    # COMPÉTENCE 4 : SÉCURISER
    # Cybersécurité, politiques et réglementations
    # ----------------------------------------------------------
    {
        "id":      "securiser",
        "label":   "Sécuriser",
        "icone":   "bi-shield-fill-check",
        "couleur": "#7cb342",            # Couleur verte
        "acs": [
            {"id": 17, "code": "AC14.01", "niveau": "acquis",         "label": "Acquérir les principes fondamentaux de la cybersécurité"},
            {"id": 18, "code": "AC14.02", "niveau": "en_cours",       "label": "Appliquer les politiques de sécurité des équipements réseau"},
            {"id": 19, "code": "AC14.03", "niveau": "en_cours",       "label": "Déceler des compromissions dans un système informatique"},
            {"id": 20, "code": "AC14.04", "niveau": "presque_acquis", "label": "Respecter les réglementations en vigueur et les bonnes pratiques"},
        ]
    },

    # ----------------------------------------------------------
    # COMPÉTENCE 5 : SURVEILLER
    # Supervision, analyse de trafic et documentation réseau
    # ----------------------------------------------------------
    {
        "id":      "surveiller",
        "label":   "Surveiller",
        "icone":   "bi-eye-fill",
        "couleur": "#0099cc",            # Couleur bleue
        "acs": [
            {"id": 21, "code": "AC15.01", "niveau": "en_cours",       "label": "Mesurer et analyser les performances d'un réseau"},
            {"id": 22, "code": "AC15.02", "niveau": "en_cours",       "label": "Caractériser et analyser le trafic réseau"},
            {"id": 23, "code": "AC15.03", "niveau": "non_acquis",     "label": "Maîtriser les outils de supervision réseau"},
            {"id": 24, "code": "AC15.04", "niveau": "presque_acquis", "label": "Documenter les réseaux et les activités de surveillance"},
        ]
    },
]