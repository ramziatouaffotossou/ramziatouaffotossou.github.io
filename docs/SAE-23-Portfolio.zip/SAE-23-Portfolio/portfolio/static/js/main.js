// ============================================================
// main.js — Portfolio Flask — Ramziatou AFFO TOSSOU
// ============================================================

var spData    = (typeof FLASK_COMPETENCES !== 'undefined') ? FLASK_COMPETENCES : [];
var spIsAdmin = (typeof FLASK_IS_ADMIN    !== 'undefined') ? FLASK_IS_ADMIN    : false;
var spNiveaux = (typeof FLASK_NIVEAUX     !== 'undefined') ? FLASK_NIVEAUX     : {};

var niveauLabels = {
  'non_acquis':     'Non acquis',
  'en_cours':       'En cours',
  'presque_acquis': 'Presque acquis',
  'acquis':         'Acquis',
  'expert':         'Expert'
};

var currentCompId = null;
var currentAcId   = null;

// ============================================================
// ANIMATION ICÔNES RÉSEAU — arrière-plan hero
// ============================================================
window.addEventListener('load', function() {
  var canvas = document.getElementById('network-canvas');
  if (!canvas) return;

  var ctx = canvas.getContext('2d');
  var W, H, t = 0;

  function resize() {
    W = canvas.width  = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  var icons = [];
  var types = ['router','switch','pc','server','firewall','wifi'];

  for (var i = 0; i < 22; i++) {
    icons.push({
      type:  types[Math.floor(Math.random() * types.length)],
      x:     Math.random() * 1400,
      y:     Math.random() * 800,
      vx:    (Math.random() - 0.5) * 0.35,
      vy:    (Math.random() - 0.5) * 0.25,
      size:  Math.random() * 10 + 10,
      alpha: Math.random() * 0.12 + 0.04,
      phase: Math.random() * Math.PI * 2
    });
  }

  function drawConnections() {
    for (var i = 0; i < icons.length; i++) {
      for (var j = i + 1; j < icons.length; j++) {
        var dx   = icons[i].x - icons[j].x;
        var dy   = icons[i].y - icons[j].y;
        var dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < 200) {
          ctx.beginPath();
          ctx.moveTo(icons[i].x, icons[i].y);
          ctx.lineTo(icons[j].x, icons[j].y);
          ctx.strokeStyle = 'rgba(0,102,204,' + (1 - dist/200) * 0.06 + ')';
          ctx.lineWidth = 0.8;
          ctx.setLineDash([3,5]);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      }
    }
  }

  function drawRouter(x, y, s, a) {
    ctx.globalAlpha = a;
    ctx.strokeStyle = '#0066cc';
    ctx.lineWidth   = 1.2;
    ctx.beginPath();
    ctx.arc(x, y, s, 0, Math.PI*2);
    ctx.stroke();
    [[-s*.5,0],[s*.5,0],[0,-s*.5],[0,s*.5]].forEach(function(d) {
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x+d[0], y+d[1]);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(x+d[0], y+d[1], 1.5, 0, Math.PI*2);
      ctx.fillStyle = '#0066cc';
      ctx.fill();
    });
    ctx.globalAlpha = 1;
  }

  function drawSwitch(x, y, s, a) {
    ctx.globalAlpha = a;
    ctx.strokeStyle = '#0066cc';
    ctx.lineWidth   = 1.2;
    ctx.beginPath();
    ctx.roundRect(x - s, y - s*.4, s*2, s*.8, 2);
    ctx.stroke();
    for (var p = 0; p < 4; p++) {
      var ledOn = Math.sin(t*3 + x + p*1.2) > 0.4;
      ctx.beginPath();
      ctx.arc(x - s*.5 + p*(s*.33), y, 1.5, 0, Math.PI*2);
      ctx.fillStyle = ledOn ? 'rgba(124,179,66,0.8)' : 'rgba(0,102,204,0.4)';
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawPC(x, y, s, a) {
    ctx.globalAlpha = a;
    ctx.strokeStyle = '#0066cc';
    ctx.lineWidth   = 1.2;
    ctx.beginPath();
    ctx.roundRect(x - s*.7, y - s*.7, s*1.4, s*1.0, 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x - s*.4, y + s*.3);
    ctx.lineTo(x + s*.4, y + s*.3);
    ctx.moveTo(x, y + s*.3);
    ctx.lineTo(x, y + s*.6);
    ctx.moveTo(x - s*.5, y + s*.6);
    ctx.lineTo(x + s*.5, y + s*.6);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  function drawServer(x, y, s, a) {
    ctx.globalAlpha = a;
    ctx.strokeStyle = '#0066cc';
    ctx.lineWidth   = 1.2;
    for (var r = 0; r < 3; r++) {
      ctx.beginPath();
      ctx.roundRect(x - s*.8, y - s*.7 + r*s*.5, s*1.6, s*.4, 2);
      ctx.stroke();
      var on = Math.sin(t*2 + r*.9 + x) > 0.2;
      ctx.beginPath();
      ctx.arc(x + s*.55, y - s*.5 + r*s*.5, 1.5, 0, Math.PI*2);
      ctx.fillStyle = on ? 'rgba(124,179,66,0.7)' : 'rgba(0,102,204,0.3)';
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawFirewall(x, y, s, a) {
    ctx.globalAlpha = a;
    ctx.strokeStyle = '#0066cc';
    ctx.lineWidth   = 1.2;
    ctx.beginPath();
    ctx.moveTo(x,          y - s);
    ctx.lineTo(x + s*.75,  y - s*.35);
    ctx.lineTo(x + s*.75,  y + s*.2);
    ctx.lineTo(x,          y + s*.9);
    ctx.lineTo(x - s*.75,  y + s*.2);
    ctx.lineTo(x - s*.75,  y - s*.35);
    ctx.closePath();
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  function drawWifi(x, y, s, a) {
    ctx.globalAlpha = a;
    ctx.strokeStyle = '#0066cc';
    ctx.lineWidth   = 1.2;
    [s*.9, s*.6, s*.3].forEach(function(r) {
      ctx.beginPath();
      ctx.arc(x, y + s*.3, r, Math.PI + 0.4, -0.4);
      ctx.stroke();
    });
    ctx.beginPath();
    ctx.arc(x, y + s*.3, 2, 0, Math.PI*2);
    ctx.fillStyle = '#0066cc';
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    t += 0.016;

    icons.forEach(function(ic) {
      ic.x += ic.vx;
      ic.y += ic.vy + Math.sin(t * 0.5 + ic.phase) * 0.15;
      if (ic.x < -50)  ic.x = W + 50;
      if (ic.x > W+50) ic.x = -50;
      if (ic.y < -50)  ic.y = H + 50;
      if (ic.y > H+50) ic.y = -50;
    });

    drawConnections();

    icons.forEach(function(ic) {
      var fn = {
        router:   drawRouter,
        switch:   drawSwitch,
        pc:       drawPC,
        server:   drawServer,
        firewall: drawFirewall,
        wifi:     drawWifi
      }[ic.type];
      if (fn) fn(ic.x, ic.y, ic.size, ic.alpha);
    });

    requestAnimationFrame(draw);
  }
  draw();
});

// ============================================================
// NAVBAR — lien actif au scroll
// ============================================================
window.addEventListener('scroll', function() {
  var links    = document.querySelectorAll('.navbar-links .nav-link');
  var sections = ['hero','resume','portfolio','support-portfolio'];
  var current  = 'hero';

  sections.forEach(function(id) {
    var el = document.getElementById(id);
    if (el && window.scrollY >= el.offsetTop - 80) current = id;
  });

  links.forEach(function(link) {
    link.classList.remove('active');
    if (link.getAttribute('href') === '#' + current) link.classList.add('active');
  });
});

// ============================================================
// OVERLAY NIVEAU 2 — liste des AC
// ============================================================
function openCompetence(id) {
  var bloc = spData.find(function(b) { return b.id === id; });
  if (!bloc) return;

  currentCompId = id;

  document.getElementById('sp-ac-comp-icon').innerHTML =
    '<i class="bi ' + bloc.icone + '" style="color:' + bloc.couleur + ';margin-right:4px"></i>';
  document.getElementById('sp-ac-comp-name').textContent = bloc.label;

  var html = '';

  // Groupe les AC par semestre
  if (bloc.semestres && bloc.semestres.length > 0) {
    bloc.semestres.forEach(function(sem) {
      if (sem.acs.length === 0) return;

      // Titre du semestre
      html += '<div style="font-size:0.75rem;font-weight:700;color:#00a8ff;' +
              'letter-spacing:2px;text-transform:uppercase;margin:14px 0 8px;' +
              'display:flex;align-items:center;gap:8px;">' +
              '<span style="background:rgba(0,102,204,0.15);border:1px solid rgba(0,102,204,0.3);' +
              'padding:2px 10px;border-radius:6px;font-family:monospace;">' + sem.code + '</span>' +
              '<span style="font-size:0.72rem;color:#a8b2d1;font-weight:400;">' + sem.nom + '</span>' +
              '</div>';

      sem.acs.forEach(function(ac) {
        var niveau    = spNiveaux[String(ac.id)] || ac.niveau;
        var niveauTxt = niveauLabels[niveau] || niveau;
        html +=
          '<div class="sp-ac-item" onclick="openReflexive(\'' + id + '\',' + ac.id + ')">' +
            '<span class="sp-ac-code" style="background:' + bloc.couleur + '22;color:' + bloc.couleur + ';border:1px solid ' + bloc.couleur + '44">' + ac.code + '</span>' +
            '<span class="sp-ac-label">' + ac.label + '</span>' +
            '<span class="niveau-' + niveau + '" style="font-size:0.71rem;padding:2px 9px;white-space:nowrap;flex-shrink:0;">' + niveauTxt + '</span>' +
            '<i class="bi bi-chevron-right sp-ac-chevron"></i>' +
          '</div>';
      });
    });
  } else {
    html = '<p style="color:#a8b2d1;font-style:italic;font-size:0.87rem;">Aucune compétence pour ce bloc.</p>';
  }

  document.getElementById('sp-ac-list').innerHTML = html;
  document.getElementById('sp-ac-overlay').classList.add('active');
  document.body.style.overflow = 'hidden';
}


function openReflexive(compId, acId) {
  var bloc = spData.find(function(b) { return b.id === compId; });
  if (!bloc) return;

  var ac = bloc.acs.find(function(a) { return a.id === acId; });
  if (!ac) return;

  currentAcId = acId;

  var codeEl = document.getElementById('sp-ref-ac-code');
  codeEl.textContent   = ac.code;
  codeEl.style.cssText =
    'background:' + bloc.couleur + '22;color:' + bloc.couleur + ';' +
    'border:1px solid ' + bloc.couleur + '44;' +
    'padding:3px 10px;border-radius:6px;font-size:0.72rem;font-weight:800;flex-shrink:0;';
  document.getElementById('sp-ref-ac-label').textContent = ac.label;

  // Boutons Modifier/Supprimer — à l'intérieur de la fonction, acId est disponible
  var actionsDiv = document.getElementById('admin-ac-actions');
  if (actionsDiv) {
    actionsDiv.innerHTML =
      '<a href="/admin/ac/' + acId + '/modifier"' +
      ' style="background:#0066cc;color:white;padding:6px 14px;border-radius:6px;' +
      'font-size:0.82rem;text-decoration:none;display:inline-flex;align-items:center;gap:5px;">' +
      '<i class="bi bi-pencil"></i> Modifier</a>' +
      '<form method="POST" action="/admin/ac/' + acId + '/supprimer"' +
      ' style="margin:0;" onsubmit="return confirm(\'Supprimer ' + ac.code + ' ?\')">' +
      '<button type="submit" style="background:rgba(220,50,50,0.15);color:#e05065;' +
      'border:1px solid rgba(220,50,50,0.4);padding:6px 14px;border-radius:6px;' +
      'font-size:0.82rem;cursor:pointer;display:inline-flex;align-items:center;gap:5px;">' +
      '<i class="bi bi-trash"></i> Supprimer</button></form>';
  }

  var questions = [
    { icon: 'bi-check2-circle',        title: "Ce que j'ai fait",          text: ac.fait         || '<em style="color:#64748b">Non renseigné.</em>' },
    { icon: 'bi-question-circle',      title: "Pourquoi je l'ai fait",     text: ac.pourquoi     || '<em style="color:#64748b">Non renseigné.</em>' },
    { icon: 'bi-tools',                title: "Comment je l'ai fait",      text: ac.comment_fait || '<em style="color:#64748b">Non renseigné.</em>' },
    { icon: 'bi-exclamation-triangle', title: "Mes difficultés",           text: ac.difficultes  || '<em style="color:#64748b">Non renseigné.</em>' },
    { icon: 'bi-lightbulb',            title: "Ce que j'en ai appris",     text: ac.appris       || '<em style="color:#64748b">Non renseigné.</em>' },
    { icon: 'bi-arrow-repeat',         title: "Ce que je ferais autrement",text: ac.autrement    || '<em style="color:#64748b">Non renseigné.</em>' }
  ];

  document.getElementById('sp-reflexive-grid').innerHTML = questions.map(function(q) {
    return '<div class="sp-ref-card">' +
      '<div class="sp-ref-card-icon"><i class="bi ' + q.icon + '"></i></div>' +
      '<h5>' + q.title + '</h5>' +
      '<p>' + q.text + '</p>' +
    '</div>';
  }).join('');

  document.getElementById('sp-project-trace').innerHTML =
    '<h5><i class="bi bi-paperclip"></i> Trace pertinente — projet lié</h5>' +
    '<p>' +
    (ac.projet_titre
      ? '<strong style="color:#fff">' + ac.projet_titre + '</strong><br>' +
        (ac.projet_desc || '') +
        (ac.projet_lien
          ? ' — <a href="' + ac.projet_lien + '" target="_blank" style="color:#00a8ff">' +
            '<i class="bi bi-github"></i> Voir sur GitHub</a>'
          : '')
      : '<span style="color:#a8b2d1;font-style:italic;">Aucun projet associé.</span>'
    ) + '</p>';

  document.getElementById('sp-reflexive-overlay').classList.add('active');
}
// ============================================================
// FERMETURE DES OVERLAYS
// ============================================================
function closeAcOverlay() {
  document.getElementById('sp-ac-overlay').classList.remove('active');
  document.body.style.overflow = '';
}

function closeReflexiveOverlay() {
  document.getElementById('sp-reflexive-overlay').classList.remove('active');
}

function closeAllOverlays() {
  document.getElementById('sp-ac-overlay').classList.remove('active');
  document.getElementById('sp-reflexive-overlay').classList.remove('active');
  document.body.style.overflow = '';
}

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') closeAllOverlays();
});