-- init.sql
-- Ce fichier est exécuté automatiquement par Docker
-- au premier démarrage du conteneur MySQL

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4; 

CREATE DATABASE IF NOT EXISTS portfolio_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;


USE portfolio_db;

-- Table des semestres
CREATE TABLE IF NOT EXISTS semestre (
    id   INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(10)  NOT NULL,
    nom  VARCHAR(100) NOT NULL
);

-- Table des blocs de compétences
CREATE TABLE IF NOT EXISTS bloc (
    id          INT PRIMARY KEY AUTO_INCREMENT,
    code        VARCHAR(20)  NOT NULL,
    nom         VARCHAR(100) NOT NULL,
    icone       VARCHAR(50),
    couleur     VARCHAR(20),
    semestre_id INT,
    FOREIGN KEY (semestre_id) REFERENCES semestre(id)
);

-- Table des apprentissages critiques
CREATE TABLE IF NOT EXISTS apprentissage_critique (
    id      INT PRIMARY KEY AUTO_INCREMENT,
    code    VARCHAR(20) NOT NULL,
    label   TEXT        NOT NULL,
    niveau  ENUM('non_acquis','en_cours','presque_acquis','acquis','expert')
            DEFAULT 'non_acquis',
    bloc_id INT,
    FOREIGN KEY (bloc_id) REFERENCES bloc(id)
);

-- Table admin (un seul compte)
CREATE TABLE IF NOT EXISTS admin (
    id            INT PRIMARY KEY AUTO_INCREMENT,
    username      VARCHAR(50)  NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL
);

-- Données initiales : semestres
INSERT INTO semestre (code, nom) VALUES
  ('S1', 'Semestre 1'),
  ('S2', 'Semestre 2');

-- Données initiales : blocs de compétences
INSERT INTO bloc (code, nom, icone, couleur, semestre_id) VALUES
  ('administrer', 'Administrer', 'bi-gear-fill',         '#c41e3a', 1),
  ('connecter',   'Connecter',   'bi-hdd-network-fill',  '#e07a3f', 1),
  ('programmer',  'Programmer',  'bi-code-slash',        '#f4c430', 1),
  ('securiser',   'Sécuriser',   'bi-shield-fill-check', '#7cb342', 1),
  ('surveiller',  'Surveiller',  'bi-eye-fill',          '#0099cc', 1);

-- Données initiales : apprentissages critiques
INSERT INTO apprentissage_critique (code, label, niveau, bloc_id) VALUES
  ('AC11.01','Maîtriser les lois fondamentales de l\'électricité','acquis',1),
  ('AC11.02','Comprendre l\'architecture des systèmes numériques','acquis',1),
  ('AC11.03','Configurer les fonctions de base du réseau local','en_cours',1),
  ('AC11.04','Maîtriser les systèmes d\'exploitation','en_cours',1),
  ('AC11.05','Identifier les dysfonctionnements du réseau','presque_acquis',1),
  ('AC11.06','Installer un poste client et expliquer la procédure','acquis',1),
  ('AC12.01','Maîtriser les technologies filaires','acquis',2),
  ('AC12.02','Maîtriser les technologies sans fil','en_cours',2),
  ('AC12.03','Mettre en place un réseau local','presque_acquis',2),
  ('AC12.04','Technologies de transmission longue distance','en_cours',2),
  ('AC12.05','Communiquer avec un client','acquis',2),
  ('AC13.01','Utiliser un système informatique','acquis',3),
  ('AC13.02','Lire et modifier un programme','acquis',3),
  ('AC13.03','Traduire un algorithme','presque_acquis',3),
  ('AC13.04','Architecture d\'un site Web','acquis',3),
  ('AC13.05','Utiliser les frameworks','acquis',3),
  ('AC14.01','Principes fondamentaux de cybersécurité','acquis',4),
  ('AC14.02','Politiques de sécurité réseau','en_cours',4),
  ('AC14.03','Déceler des compromissions','en_cours',4),
  ('AC14.04','Respecter les réglementations','presque_acquis',4),
  ('AC15.01','Mesurer les performances réseau','en_cours',5),
  ('AC15.02','Analyser le trafic réseau','en_cours',5),
  ('AC15.03','Outils de supervision','non_acquis',5),
  ('AC15.04','Documenter les réseaux','presque_acquis',5);